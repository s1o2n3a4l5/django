# multiple_image_upload_drf
Learn how to implement multiple image upload on the backend using Django rest framework.
